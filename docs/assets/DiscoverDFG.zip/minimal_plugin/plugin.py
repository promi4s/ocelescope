from typing import Annotated

from ocelescope import OCEL, OCEL_FIELD, DotVis, OCELAnnotation, Plugin, PluginInput, Resource, plugin_method

from .util import convert_dfg_to_graphviz, discover_dfg


class DFG(Resource):
    label = "DFG"
    description = "An object-centric directly follows graph"

    edges: list[tuple[str | None, str, str | None]]

    def visualize(self):
        graphviz_instance = convert_dfg_to_graphviz(self.edges)

        return DotVis.from_graphviz(graphviz_instance)


class Input(PluginInput):
    object_types: list[str] = OCEL_FIELD(field_type="object_type", ocel_id="ocel")


class DiscoverDFG(Plugin):
    label = "DFG Discovery"
    description = "A plugin for discovering object-centric directly-follows graphs"
    version = "0.1.0"

    @plugin_method(label="Discover DFG", description="Discovers an object-centric directly-follows graph")
    def discover(
        self,
        ocel: Annotated[OCEL, OCELAnnotation(label="Event Log")],
        input: Input,
    ) -> DFG:
        edges = discover_dfg(ocel=ocel, used_object_types=input.object_types)

        return DFG(edges=edges)
