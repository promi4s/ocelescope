from .plugin import DiscoverDFG

__all__ = [
    "DiscoverDFG",
]
